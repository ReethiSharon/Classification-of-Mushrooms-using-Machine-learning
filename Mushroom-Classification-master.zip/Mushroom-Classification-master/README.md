# Mushroom_Classification

### This project aims at developing a machine-learning algorithm that will determine if a certain mushroom is edible or poisonous by its specifications like cap shape, cap color, gill color, etc. using different classifiers. 
#### To do so, I have used the following classification methods:
- **Decision Tree Classifier**
- **Logistic Regression Classifier**
- **k-Nearest Neighbor Classifier**
- **Support Vector Machine Classifier**
- **Naive Bayes Classifier**
- **Random Forest Classifier**
